<?php

namespace Admin\Controller;

/**
 * 广告管理控制器
 * 
 * @author Anyon <cxphp@qq.com>
 * @date 2014/04/06 20:08
 */
class AdController extends \Admin\Controller\AdminController {
	
}
