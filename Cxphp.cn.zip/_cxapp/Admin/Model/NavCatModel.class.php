<?php

namespace Admin\Model;

class NavCatModel extends \Admin\Model\CommonModel {
	
}
