<?php

namespace Admin\Model;

class NavModel extends \Admin\Model\CommonModel {
	
}
