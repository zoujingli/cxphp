<?php

namespace Admin\Model;

class RoleModel extends \Admin\Model\CommonModel {

	//自动验证
	protected $_validate = array(
	);

}
