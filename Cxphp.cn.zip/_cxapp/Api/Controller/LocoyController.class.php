<?php

namespace Api\Controller;

class LocoyController extends \Admin\Controller {

	function index() {
		$this->display();
	}

}
