<?php

return array(
	'TMPL_PARSE_STRING' => array(
		'__STATIC__' => __ROOT__ . '/static',
	)
);
